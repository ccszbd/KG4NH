exit 0;

export MODEL=BioLinkBERT-base
export MODEL_PATH=michiyasunaga/$MODEL

############################### RE: GAD ###############################
task=GAD_hf
datadir=../data/seqcls/$task
outdir=runs/$task/$MODEL
mkdir -p $outdir
python3 -u seqcls/run_seqcls.py --model_name_or_path $MODEL_PATH \
  --train_file $datadir/train.json --validation_file $datadir/dev.json --test_file $datadir/test.json \
  --do_train --do_eval=false --do_predict --metric_name PRF1 \
  --per_device_train_batch_size 32 --gradient_accumulation_steps 1 --fp16 \
  --learning_rate 3e-5 --num_train_epochs 10 --max_seq_length 256 \
  --save_strategy no --evaluation_strategy no --output_dir $outdir --overwrite_output_dir \
  |& tee $outdir/log.txt &

